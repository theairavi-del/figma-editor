// Color selection
document.querySelectorAll('.color-btn').forEach(btn => {
    btn.addEventListener('click', function() {
        document.querySelectorAll('.color-btn').forEach(b => b.classList.remove('active'));
        this.classList.add('active');
    });
});

// Thumbnail selection
document.querySelectorAll('.thumb').forEach(thumb => {
    thumb.addEventListener('click', function() {
        document.querySelectorAll('.thumb').forEach(t => t.classList.remove('active'));
        this.classList.add('active');
    });
});

// Quantity controls
const qtyValue = document.querySelector('.qty-value');
let quantity = 1;

document.querySelectorAll('.qty-btn').forEach(btn => {
    btn.addEventListener('click', function() {
        if (this.textContent === '-') {
            quantity = Math.max(1, quantity - 1);
        } else {
            quantity = Math.min(10, quantity + 1);
        }
        qtyValue.textContent = quantity;
    });
});

// Add to cart
document.querySelector('.btn-primary').addEventListener('click', function() {
    const cartCount = document.querySelector('.cart-count');
    cartCount.textContent = parseInt(cartCount.textContent) + quantity;
    
    // Animation feedback
    this.textContent = 'Added!';
    this.style.background = '#22c55e';
    
    setTimeout(() => {
        this.textContent = 'Add to Cart';
        this.style.background = '';
    }, 1500);
});

// Smooth scroll
document.querySelectorAll('a[href^="#"]').forEach(anchor => {
    anchor.addEventListener('click', function(e) {
        e.preventDefault();
        const target = document.querySelector(this.getAttribute('href'));
        if (target) {
            target.scrollIntoView({ behavior: 'smooth' });
        }
    });
});

// Feature box animation
const observer = new IntersectionObserver((entries) => {
    entries.forEach((entry, index) => {
        if (entry.isIntersecting) {
            setTimeout(() => {
                entry.target.style.opacity = '1';
                entry.target.style.transform = 'translateY(0)';
            }, index * 100);
        }
    });
}, { threshold: 0.1 });

document.querySelectorAll('.feature-box').forEach(box => {
    box.style.opacity = '0';
    box.style.transform = 'translateY(30px)';
    box.style.transition = 'opacity 0.6s ease, transform 0.6s ease';
    observer.observe(box);
});

console.log('Product page loaded successfully!');
